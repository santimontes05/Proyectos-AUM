console.log("Hello world");

var a= 1 ;
var b= 2 ;
var r= a + b ; 
console.log("Resultado: " + r);

var c= 1 ;
var f= 2 ;
var d= c * f ; 
console.log("Resultado: " + d);

var i= Math.sqrt(1244)
console.log("Resultado: " + i);
var j= Math.round(i)
console.log("Resultado: "+ j);

var w = 200;
var q = 2;
var Primos = [];

for (; q < w; q++) {

  if (primo(q)) {
    Primos.push(q);
  }
  
}

console.log("Los numero primos hasta el 500.000 son: " + Primos);

function primo(numero) {

  for (var v = 2; v < numero; v++) {

    if (numero % v === 0) {
      return false;
    }

  }

  return numero !== 1;
}

